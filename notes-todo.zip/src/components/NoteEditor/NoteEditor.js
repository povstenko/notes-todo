import React from 'react';
import PropTypes from 'prop-types';
import './NoteEditor.css';

const NoteEditor = () => (
  <div className="NoteEditor">
    NoteEditor Component
  </div>
);

NoteEditor.propTypes = {};

NoteEditor.defaultProps = {};

export default NoteEditor;
