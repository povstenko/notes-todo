import React from 'react';
import PropTypes from 'prop-types';
import './NotFoundPage.css';

const NotFoundPage = () => (
  <div className="NotFoundPage">
    NotFoundPage Component
  </div>
);

NotFoundPage.propTypes = {};

NotFoundPage.defaultProps = {};

export default NotFoundPage;
