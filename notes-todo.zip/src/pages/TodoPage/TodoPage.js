import React from 'react';
import PropTypes from 'prop-types';
import './TodoPage.css';

const TodoPage = () => (
  <div className="TodoPage">
    TodoPage Component
  </div>
);

TodoPage.propTypes = {};

TodoPage.defaultProps = {};

export default TodoPage;
