import React from 'react';
import './AboutPage.css';

const AboutPage = () => (
  <div className="about-page">
    <h1 className="about-header">About Page</h1>
  </div>
);

AboutPage.propTypes = {};

AboutPage.defaultProps = {};

export default AboutPage;
